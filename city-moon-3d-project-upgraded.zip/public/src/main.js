import * as THREE from 'three';
import { buildWorld, LOCATIONS, colliders, roadSpots, BOUNDS } from './world.js';
import { setupSky } from './sky.js';
import { Player, Character, CameraRig } from './player.js';
import { Input } from './input.js';
import { story, CAST, PLAYER_FILE } from './story.js';
import { Sound } from './audio.js';

const $ = id => document.getElementById(id);
const SAVE_KEY = 'cityMoon3dSave', PREF_KEY = 'cityMoon3dPrefs', SLOT_KEY = 'cityMoon3dSlot';
const SAVE_SCHEMA = 2;
const lsGet = k => { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
const prefs = Object.assign({ quality: matchMedia('(pointer:coarse)').matches ? 'low' : 'high', sound: true }, lsGet(PREF_KEY) || {});
const HIGH = prefs.quality === 'high';

// ---------- renderer / scene ----------
const renderer = new THREE.WebGLRenderer({ antialias: HIGH, powerPreference: 'high-performance' });
renderer.setPixelRatio(HIGH ? Math.min(devicePixelRatio, 2) : 1);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = HIGH; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15;
document.body.prepend(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(62, 1, 0.1, 600);
const sky = setupSky(scene, HIGH);
function resize() { renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();

const sound = new Sound(); sound.on = prefs.sound;
const input = new Input(renderer.domElement);
input.enabled = false;

// ---------- load ----------
const bar = document.querySelector('#bar span');
let loadedN = 0; const step = f => { bar.style.width = Math.min(100, (loadedN + f) * 100 / 3) + '%'; };
const world = await buildWorld(scene, p => step(p)); loadedN = 1;
const player = new Player(); await player.init(scene, PLAYER_FILE); loadedN = 2;
const npcs = {}; let ci = 0;
for (const [k, d] of Object.entries(CAST)) {
  const n = new Character(); await n.init(scene, d.file, d.height || 1.8); n.root.visible = false; n.key = k; npcs[k] = n; step(++ci / Object.keys(CAST).length * 0 + 0);
}
loadedN = 3; step(0);
const rig = new CameraRig(camera);

// ---------- beacon, orbs ----------
const beacon = new THREE.Group();
{
  const mat = new THREE.MeshBasicMaterial({ color: 0xffd98a, transparent: true, opacity: .22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
  const col = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 40, 20, 1, true), mat); col.position.y = 20; beacon.add(col);
  const ring = new THREE.Mesh(new THREE.RingGeometry(2.1, 2.6, 40), new THREE.MeshBasicMaterial({ color: 0xffd98a, transparent: true, opacity: .8, side: THREE.DoubleSide, fog: false }));
  ring.rotation.x = -Math.PI / 2; ring.position.y = .08; beacon.add(ring); beacon.visible = false; scene.add(beacon);
}
const orbs = [];
{
  const r = (() => { let s = 99; return () => (s = (s * 16807) % 2147483647) / 2147483647; })();
  const pool = roadSpots.slice(); const geo = new THREE.IcosahedronGeometry(.35, 1);
  for (let i = 0; i < 10 && pool.length; i++) {
    const [x, z] = pool.splice(Math.floor(r() * pool.length), 1)[0];
    const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: 0xbfe8ff, fog: false }));
    const halo = new THREE.Mesh(new THREE.SphereGeometry(.75, 12, 8), new THREE.MeshBasicMaterial({ color: 0x7fc4ff, transparent: true, opacity: .25, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
    m.add(halo); m.position.set(x, 1.1, z); m.userData = { id: i, t: r() * 6, got: false }; scene.add(m); orbs.push(m);
  }
}

// ---------- game state ----------
const fresh = () => ({ schema: SAVE_SCHEMA, scene: 'opening', pending: 'opening', loc: 'home', trust: 0, clues: [], compassion: 0, orbs: [], history: [], flags: {}, pos: [0, 18], yaw: 0 });
function normalizeSave(raw) {
  if (!raw || typeof raw !== 'object' || !Array.isArray(raw.pos) || raw.pos.length < 2 || !raw.pos.every(Number.isFinite)) return null;
  const next = Object.assign(fresh(), raw);
  if (!story[next.scene]) next.scene = 'opening';
  if (next.pending && !story[next.pending]) next.pending = null;
  next.pos = [THREE.MathUtils.clamp(next.pos[0], -BOUNDS, BOUNDS), THREE.MathUtils.clamp(next.pos[1], -BOUNDS, BOUNDS)];
  next.yaw = Number.isFinite(next.yaw) ? next.yaw : 0;
  next.trust = Number.isFinite(next.trust) ? next.trust : 0;
  next.compassion = Number.isFinite(next.compassion) ? next.compassion : 0;
  next.clues = Array.isArray(next.clues) ? next.clues.filter(v => typeof v === 'string').slice(0, 100) : [];
  next.orbs = Array.isArray(next.orbs) ? [...new Set(next.orbs.filter(v => Number.isInteger(v) && v >= 0 && v < 10))] : [];
  next.history = Array.isArray(next.history) ? next.history.filter(v => v && typeof v.title === 'string').slice(-100) : [];
  next.flags = next.flags && typeof next.flags === 'object' ? next.flags : {}; next.schema = SAVE_SCHEMA;
  return next;
}
let state = fresh(), mode = 'title';   // title | play | dialog
const save = () => { state.pos = [player.pos.x, player.pos.z]; state.yaw = rig.yaw; state.schema = SAVE_SCHEMA; state.savedAt = Date.now(); lsSet(SAVE_KEY, state); };
function toast(msg, ms = 2200) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove('show'), ms); }
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function hud() {
  $('sTrust').textContent = state.trust; $('sClues').textContent = state.clues.length; $('sComp').textContent = state.compassion;
  $('sOrbs').textContent = state.orbs.length + '/' + orbs.length;
}
function applyOrbs() { orbs.forEach(o => { o.userData.got = state.orbs.includes(o.userData.id); o.visible = !o.userData.got; }); }

// ---------- NPC staging ----------
function hideNpcs() { Object.values(npcs).forEach(n => { n.root.visible = false; n.col = null; n.ambientActive = false; }); for (let i = colliders.length - 1; i >= 0; i--) if (colliders[i].npc) colliders.splice(i, 1); }
const AMBIENT_ROUTES = { conductor: [[24, 24], [24, 36]], passengerA: [[0, 0], [0, 24]], passengerB: [[-24, -24], [-24, 0]] };
function updateAmbientNpcs(dt) {
  if (mode !== 'play' || npcHideT > 0) return;
  for (const [key, route] of Object.entries(AMBIENT_ROUTES)) {
    const n = npcs[key]; if (!n) continue;
    if (!n.ambientActive) { n.ambientActive = true; n.ambientTarget = 1; n.root.position.set(route[0][0], 0, route[0][1]); n.root.visible = true; n.play('walk'); colliders.push({ x: route[0][0], z: route[0][1], r: .48, h: 0, npc: true, ambientKey: key }); }
    const target = route[n.ambientTarget]; const dx = target[0] - n.root.position.x, dz = target[1] - n.root.position.z, d = Math.hypot(dx, dz);
    if (d < .7) { n.root.position.set(target[0], 0, target[1]); n.ambientTarget = 1 - n.ambientTarget; n.play('idle'); }
    else { n.root.position.x += dx / d * Math.min(d, .8 * dt); n.root.position.z += dz / d * Math.min(d, .8 * dt); n.face(dx, dz, dt, 3); n.play('walk'); }
    const c = colliders.find(v => v.npc && v.ambientKey === key); if (c) { c.x = n.root.position.x; c.z = n.root.position.z; }
  }
}
function showCast(list, loc) {
  hideNpcs();
  const fx = -Math.sin(rig.yaw), fz = -Math.cos(rig.yaw);       // camera-forward on the ground
  let ax, az, dx, dz, lx, lz;
  if (loc === 'street') { ax = player.pos.x + fx * 3.2; az = player.pos.z + fz * 3.2; lx = -fz; lz = fx; }
  else { [ax, az] = LOCATIONS[loc].marker; const sg = fz >= 0 ? 1 : -1; ax += 0; az += sg * 3; lx = 1; lz = 0; }   // all story markers sit on z-running roads
  list.forEach((k, i) => {
    const n = npcs[k], sp = (i - (list.length - 1) / 2) * 1.5 + 1.5, px = ax + lx * sp, pz = az + lz * sp;
    n.root.position.set(px, 0, pz); n.root.visible = true; n.play('idle');
    colliders.push({ x: px, z: pz, r: .5, h: 0, npc: true });
  });
}

// ---------- dialogue ----------
const needClue = c => !c.requires || !((c.requires.clues && state.clues.length < c.requires.clues) || (c.requires.trust && state.trust < c.requires.trust) || (c.requires.compassion && state.compassion < c.requires.compassion));
function openScene(id) {
  const sc = story[id]; if (!sc) return;
  state.scene = id; state.pending = null; state.loc = sc.loc === 'street' ? state.loc : sc.loc;
  state.history.push({ id, title: sc.title, chapter: sc.chapter });
  mode = 'dialog'; input.enabled = false; input.joy.x = input.joy.y = 0; beacon.visible = false;
  showCast(sc.cast, sc.loc);
  $('dChap').textContent = `Chapter ${sc.chapter} · ${sc.chapterName}`; $('dTitle').textContent = sc.title; $('dText').textContent = sc.text;
  $('dNpc').textContent = sc.cast.length ? sc.cast.map(k => CAST[k].name).filter((v, i, a) => a.indexOf(v) === i).join(' · ') : '';
  const box = $('dChoices'); box.innerHTML = '';
  sc.choices.filter(needClue).forEach(c => { const b = document.createElement('button'); b.className = 'choice'; b.textContent = c.label; b.onclick = () => { sound.click(); choose(c); }; box.appendChild(b); });
  $('dialog').classList.add('show'); document.body.classList.add('dlg'); $('dialog').scrollTop = 0; $('dText').scrollTop = 0;
  if (sc.ending) { sound.ending(); } else sound.chime();
  hud(); save();
}
function choose(c) {
  const e = c.effects || {}; let gained = false;
  if (e.trust) state.trust += e.trust; if (e.compassion) state.compassion += e.compassion;
  if (e.clue && !state.clues.includes(e.clue)) { state.clues.push(e.clue); gained = true; }
  if (c.log) state.flags[c.log] = true;
  $('dialog').classList.remove('show'); document.body.classList.remove('dlg'); hud();
  if (c.next === 'home') { state = fresh(); lsSet(SAVE_KEY, null); hideNpcs(); showTitle(); return; }
  mode = 'play'; input.enabled = true; hideNpcsSoon();
  if (gained) { player.once('pick-up', .9); toast('Clue found: ' + e.clue); sound.chime(); }
  queueScene(c.next); save();
}
let npcHideT = 0; function hideNpcsSoon() { npcHideT = 1.2; }
function queueScene(id) {
  state.pending = id; const sc = story[id];
  if (sc.loc === 'street') { setTimeout(() => { if (state.pending === id && mode === 'play') openScene(id); }, 650); return; }
  checkArrive();
}
function checkArrive() {
  if (!state.pending || mode !== 'play') return;
  const sc = story[state.pending], L = LOCATIONS[sc.loc]; if (!L) return;
  const d = Math.hypot(player.pos.x - L.marker[0], player.pos.z - L.marker[1]);
  if (d < 2.8) openScene(state.pending);
}

// ---------- interaction / save backups ----------
function collectOrb(o) {
  if (!o || o.userData.got) return;
  o.userData.got = true; o.visible = false; state.orbs.push(o.userData.id); sound.chime(); player.once('pick-up', .8);
  toast(`Memory fragment ${state.orbs.length}/${orbs.length}`);
  if (state.orbs.length === 5 && !state.clues.includes('Moon fragments')) { state.clues.push('Moon fragments'); setTimeout(() => toast('Clue found: Moon fragments'), 1700); }
  hud(); save();
}
function interactWorld() {
  let nearest = null, dist = Infinity;
  for (const o of orbs) if (!o.userData.got) { const d = Math.hypot(o.position.x - player.pos.x, o.position.z - player.pos.z); if (d < dist) { nearest = o; dist = d; } }
  if (nearest && dist < 3.4) { collectOrb(nearest); return; }
  const nearby = Object.entries(npcs).find(([key, n]) => n.ambientActive && n.root.visible && Math.hypot(n.root.position.x - player.pos.x, n.root.position.z - player.pos.z) < 2.8 && !state.flags['sidequest-' + key]);
  if (nearby) {
    const [key, n] = nearby; state.flags['sidequest-' + key] = true;
    const clue = key === 'conductor' ? 'Platform Zero timetable' : key === 'passengerA' ? 'A name remembered kindly' : 'A promise beneath the streetlamp';
    if (!state.clues.includes(clue)) state.clues.push(clue);
    if (key === 'conductor') state.trust += 1; else state.compassion += 1;
    toast(`${n.key === 'conductor' ? 'Conductor' : 'Passenger'} shared a side-quest clue`); sound.chime(); hud(); save(); return;
  }
  toast('Move closer to a blue memory or a passerby to interact.');
}
function saveSlot(slot) { save(); lsSet(SLOT_KEY + slot, state); toast(`Save slot ${slot} updated`); }
function loadSlot(slot) {
  const loaded = normalizeSave(lsGet(SLOT_KEY + slot)); if (!loaded) { toast(`Save slot ${slot} is empty or invalid`); return; }
  state = loaded; player.pos.set(state.pos[0], 0, state.pos[1]); player.vel.set(0, 0, 0); rig.yaw = state.yaw; rig.target.set(state.pos[0], 1.6, state.pos[1]);
  lsSet(SAVE_KEY, state); $('modal').classList.remove('show'); enterGame(); applyOrbs(); if (state.pending) queueScene(state.pending); hud(); toast(`Loaded save slot ${slot}`);
}
function exportSave() {
  save(); const payload = JSON.stringify({ game: 'The City That Forgot the Moon', version: SAVE_SCHEMA, save: state }, null, 2);
  if (window.AndroidBridge?.exportSave) { window.AndroidBridge.exportSave(payload); toast('Choose an app or Files destination to keep the backup.'); return; }
  const url = URL.createObjectURL(new Blob([payload], { type: 'application/json' })); const a = document.createElement('a'); a.href = url; a.download = 'city-moon-save.json'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); toast('Save backup exported');
}
function importSaveFile(file) {
  if (!file) return; const reader = new FileReader();
  reader.onload = () => { try { const parsed = JSON.parse(reader.result); const loaded = normalizeSave(parsed.save || parsed); if (!loaded) throw new Error('Invalid save'); state = loaded; lsSet(SAVE_KEY, state); $('modal').classList.remove('show'); showTitle(); toast('Save backup imported'); } catch (e) { toast('That file is not a valid City Moon save.'); } };
  reader.readAsText(file);
}
// ---------- journal / menus ----------
function modal(title, html) { $('mTitle').textContent = title; $('mBody').innerHTML = html; $('modal').classList.add('show'); }
function journal() {
  if (mode === 'title') return;
  const clues = state.clues.map(c => `<li>${esc(c)}</li>`).join('') || '<li>No clues collected yet.</li>';
  const hist = state.history.slice(-14).map(h => `<li><b>Ch.${h.chapter}</b> ${esc(h.title)}</li>`).join('') || '<li>—</li>';
  const goal = state.pending ? `Go to: <b>${esc(LOCATIONS[story[state.pending].loc]?.name || 'the street')}</b>` : 'Explore the city';
  modal('Ren’s Journal', `<p>${goal}</p><p>Trust ${state.trust} · Clues ${state.clues.length} · Compassion ${state.compassion} · Memory fragments ${state.orbs.length}/${orbs.length}</p><h3>Clues</h3><ul>${clues}</ul><h3>Recent scenes</h3><ul>${hist}</ul>`);
}
input.onJournal = journal; $('btnJournal').onclick = journal;
$('mClose').onclick = () => $('modal').classList.remove('show');
$('btnSoundHud').onclick = () => { prefs.sound = !prefs.sound; sound.setOn(prefs.sound); lsSet(PREF_KEY, prefs); $('btnSoundHud').textContent = prefs.sound ? '🔊' : '🔇'; };
$('btnSoundHud').textContent = prefs.sound ? '🔊' : '🔇';
$('btnMenu').onclick = () => modal('Menu & Save Manager', `<div class="row"><button class="choice" id="mSave">Save current game</button><div class="row"><button class="choice" id="mSlotSave1">Save slot 1</button><button class="choice" id="mSlotLoad1">Load slot 1</button><button class="choice" id="mSlotSave2">Save slot 2</button><button class="choice" id="mSlotLoad2">Load slot 2</button><button class="choice" id="mSlotSave3">Save slot 3</button><button class="choice" id="mSlotLoad3">Load slot 3</button></div><button class="choice" id="mExport">Export save backup (JSON)</button><button class="choice" id="mImport">Import save backup</button><input id="mImportFile" type="file" accept="application/json,.json" hidden><button class="choice" id="mTitleBtn">Back to title</button></div><p class="dim">Mobile: left thumb moves, right thumb looks; ACT collects nearby memories or asks a passerby for a clue. RUN toggles sprint. Saves stay on this device unless you export a backup.</p>`);
document.addEventListener('click', e => {
  if (e.target.id === 'mSave') { save(); toast('Saved'); $('modal').classList.remove('show'); }
  if (e.target.id === 'mTitleBtn') { save(); $('modal').classList.remove('show'); hideNpcs(); showTitle(); }
  const slotSave = e.target.id.match(/^mSlotSave([123])$/); if (slotSave) saveSlot(Number(slotSave[1]));
  const slotLoad = e.target.id.match(/^mSlotLoad([123])$/); if (slotLoad) loadSlot(Number(slotLoad[1]));
  if (e.target.id === 'mExport') exportSave();
  if (e.target.id === 'mImport') $('mImportFile')?.click();
});
document.addEventListener('change', e => { if (e.target.id === 'mImportFile') importSaveFile(e.target.files?.[0]); });
input.onInteract = interactWorld;

// ---------- title ----------
function showTitle() {
  mode = 'title'; input.enabled = false; $('title').classList.remove('hidden'); $('hudTop').classList.add('hidden'); $('controls').classList.add('hidden'); beacon.visible = false;
  $('btnContinue').style.display = lsGet(SAVE_KEY) ? '' : 'none';
  $('btnQuality').textContent = 'Graphics: ' + (HIGH ? 'High' : 'Low (battery saver)');
}
function enterGame() { $('title').classList.add('hidden'); $('hudTop').classList.remove('hidden'); $('controls').classList.remove('hidden'); mode = 'play'; input.enabled = true; hud(); applyOrbs(); sound.start(); sound.setOn(prefs.sound); }
$('btnBegin').onclick = () => { state = fresh(); player.pos.set(0, 0, 18); player.vel.set(0, 0, 0); rig.yaw = 0; rig.target.set(0, 1.6, 18); enterGame(); lsSet(SAVE_KEY, null); applyOrbs(); setTimeout(() => openScene('opening'), 900); };
$('btnContinue').onclick = () => {
  const s = normalizeSave(lsGet(SAVE_KEY)); if (!s) { toast('No valid save found on this device.'); return; } state = s;
  player.pos.set(state.pos[0], 0, state.pos[1]); rig.yaw = state.yaw || 0; rig.target.set(state.pos[0], 1.6, state.pos[1]); enterGame();
  if (state.pending) queueScene(state.pending); else if (story[state.scene]?.ending) { /* ended */ }
};
$('btnQuality').onclick = () => { prefs.quality = HIGH ? 'low' : 'high'; lsSet(PREF_KEY, prefs); location.reload(); };

// ---------- loop ----------
let vs = 0;
function viewShift(dt) {
  const want = mode === 'dialog' ? 1 : 0; vs += (want - vs) * Math.min(1, dt * 6);
  const side = innerHeight <= 500 && innerWidth > innerHeight;
  if (vs < 0.002) { if (camera.view && camera.view.enabled) camera.clearViewOffset(); return; }
  const w = innerWidth, h = innerHeight;
  camera.setViewOffset(w, h, side ? w * 0.2 * vs : 0, side ? 0 : h * 0.2 * vs, w, h);
}
const clock = new THREE.Clock(); let t = 0, arrow = $('objArrow');
function frame() {
  const dt = Math.min(clock.getDelta(), 0.05); t += dt;
  const a = input.consume();
  if (mode === 'title') {
    rig.yaw += dt * 0.12; rig.target.set(0, 3, 12); const r = 22; camera.position.set(Math.sin(rig.yaw) * r, 7, 12 + Math.cos(rig.yaw) * r); camera.lookAt(0, 4, 8);
    player.update(dt, { x: 0, y: 0 }, 0, { sprint: false }, colliders, BOUNDS);
  } else {
    const ev = player.update(dt, input.move(), rig.yaw, { sprint: input.sprint, jump: a.jump && input.enabled }, colliders, BOUNDS);
    if (ev.step) sound.step(); if (ev.jumped) sound.jump(); if (ev.landed) sound.land();
    rig.update(dt, player, mode === 'dialog' ? { x: 0, y: 0 } : a.look, colliders);
    if (mode === 'play') {
      checkArrive();
      for (const o of orbs) if (!o.userData.got && Math.hypot(o.position.x - player.pos.x, o.position.z - player.pos.z) < 1.9) collectOrb(o);
      if (a.interact && input.enabled) interactWorld();
      // objective HUD
      const p = state.pending && story[state.pending], L = p && LOCATIONS[p.loc];
      if (L) {
        beacon.visible = true; beacon.position.set(L.marker[0], 0, L.marker[1]);
        const dx = L.marker[0] - player.pos.x, dz = L.marker[1] - player.pos.z;
        $('objText').textContent = `${L.name} · ${Math.round(Math.hypot(dx, dz))} m`;
        const rx = Math.cos(rig.yaw), rz = -Math.sin(rig.yaw), fx = -Math.sin(rig.yaw), fz = -Math.cos(rig.yaw);
        arrow.style.transform = `rotate(${Math.atan2(dx * rx + dz * rz, dx * fx + dz * fz)}rad)`; $('objective').classList.remove('hidden');
      } else { beacon.visible = false; $('objective').classList.add('hidden'); }
    }
  }
  if (npcHideT > 0) { npcHideT -= dt; if (npcHideT <= 0 && mode === 'play') hideNpcs(); }
  updateAmbientNpcs(dt);
  for (const n of Object.values(npcs)) if (n.root.visible) { n.update(dt); if (!n.ambientActive) n.face(player.pos.x - n.root.position.x, player.pos.z - n.root.position.z, dt, 6); }
  for (const o of orbs) if (o.visible) { o.userData.t += dt; o.position.y = 1.1 + Math.sin(o.userData.t * 2) * .2; o.rotation.y += dt; }
  beacon.children[0].material.opacity = .18 + Math.sin(t * 3) * .05; beacon.children[1].scale.setScalar(1 + Math.sin(t * 3) * .06);
  world.tower.userData.light.intensity = 50 + Math.sin(t * 1.3) * 18;
  viewShift(dt);
  sky.update(camera);
  renderer.render(scene, camera);
  requestAnimationFrame(frame);
}
$('loading').style.opacity = 0; setTimeout(() => $('loading').remove(), 700);
showTitle();
window.__game = { state: () => state, player, rig, openScene, mode: () => mode, orbs, npcs, LOCATIONS, queueScene, input };
window.__ready = true;
frame();
