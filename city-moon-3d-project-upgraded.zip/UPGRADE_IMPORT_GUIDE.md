# Import the upgraded game and build the APK

The current GitHub default branch contains an older prototype and does not yet contain the upgraded Three.js source tree (`public/` and `android/`). The corrected APK workflow packages the real project rather than generating a different placeholder game.

## Easiest method on Android

1. Upload `city-moon-3d-project-upgraded.zip` to the repository root with that exact filename using **Add file → Upload files**.
2. Commit the upload to `main`.
3. Open **Actions → Build City Moon 3D APK** and wait for the run to finish.
4. Download `city-moon-3d-debug-apk` from the successful run's **Artifacts** section.

The workflow extracts the ZIP in its temporary runner workspace and builds from its `android/` folder. It does not commit the extracted source files. Alternatively, upload the ZIP's `public/`, `android/`, `tools/test-source.mjs`, and `PLAN.md` contents to the repository root; the workflow detects that layout too.

## Validation

The workflow checks JavaScript syntax and required local assets, runs source smoke tests, builds with Java 17 and Gradle 8.7, verifies the APK is non-empty, and only then uploads it. A successful build still needs real-device gameplay testing.
