# The City That Forgot the Moon: 3D build plan
Resume rule: do the first step not marked DONE, then mark it DONE here.

- [x] Step 1: skeleton, selected Kenney assets copied to public/assets, manifest.json
- [x] Step 2 (DONE, verified in headless Chromium): Three.js scene: loader, moonlit sky, fog, ground, road grid + buildings + trees
- [x] Step 3 (DONE, tested): player (character-male-a/female-a), camera-relative movement from Godot controller (accel 6, speed 8, rotation 12), idle/walk/sprint/jump animations, third-person camera with collision
- [x] Step 4 (DONE, tested): touch controls (joystick + jump/interact buttons), keyboard, Android WebView friendly
- [x] Step 5 (DONE, tested): story layer: NPCs (Mira, Clockmaker, child), memory-object pickups, reuse story data from index.html, journal/clues HUD
- [x] Step 6 (DONE, tested): polish (red moon, lights, audio hooks), save/load, performance pass
- [x] Step 7 (DONE): single-file offline build + Android WebView wrapper notes

Notes
- Bundler (esbuild) is blocked in this sandbox; use native ES modules + importmap, three@0.170.0 vendored in public/vendor.
- Godot demo is a robot shooter: port movement feel only.
- All assets CC0 (Kenney).
- vendored: public/vendor/three.module.js + addons (GLTFLoader, SkeletonUtils); importmap maps 'three' and 'three/addons/'
- Run locally: cd public && python3 -m http.server 8123, open http://localhost:8123 (?cam=top for map view)
- Screenshot test: python3 -I tools/shot.py URL out.png
- GLBs need their own Textures/colormap.png per folder (each pack's texture differs).
- Code: public/src/{main,world,sky,loader}.js. World scale SC=6 units/tile; lots[] holds building circles for collision (used in Step 3).

## STATUS: all 7 steps done (v0.1). Next ideas (not started)
- Verify frame rate on a real phone; if slow: merge static meshes / InstancedMesh, fewer PointLights
- Add more NPC wandering, side quests, voice/music files, minimap
- Replace procedural clock tower / train with custom models
- Tune TUNE in src/player.js (walk 6.5, run 11, jump 11)
## Build / run
- Dev: cd public && python3 -m http.server 8123
- Offline single file: python3 tools/build_single.py -> dist/city-moon-offline.html (needs bun + npm i three@0.170.0)
- Android: see android/README.md
- Tests: tools/play_test2.py (playthrough), tools/file_test.py (file:// build)


## Upgrade pass (balanced mobile target)
- Android packaging must copy `public/` to `android/app/src/main/assets/www/` and build that Android project. Never generate a different placeholder game in CI.
- Mobile ACT/RUN/JUMP controls, validated save migration, three manual save slots, JSON export/import, ambient NPC patrols with optional side-quest clues, and background-aware procedural audio are implemented in the editable source.
- CI source checks validate key interaction/save/NPC hooks and required local assets before attempting the Android build.
