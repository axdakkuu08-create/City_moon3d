import * as THREE from 'three';

// Night sky with a big crimson moon, stars, fog and moonlight.
export function setupSky(scene, shadows = true) {
  scene.background = new THREE.Color(0x0e1226);
  scene.fog = new THREE.Fog(0x1a1530, 40, 190);

  const dome = new THREE.Mesh(new THREE.SphereGeometry(400, 32, 16), new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color(0x070a1c) }, mid: { value: new THREE.Color(0x2b2547) }, hor: { value: new THREE.Color(0x6b3454) } },
    vertexShader: 'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader: 'uniform vec3 top,mid,hor;varying vec3 p;void main(){float h=normalize(p).y;vec3 c=mix(hor,mid,smoothstep(0.,.25,h));c=mix(c,top,smoothstep(.2,.8,h));gl_FragColor=vec4(c,1.);}'
  }));
  scene.add(dome);

  const moon = new THREE.Mesh(new THREE.SphereGeometry(28, 32, 24), new THREE.MeshBasicMaterial({ color: 0xe0788c, fog: false }));
  moon.position.set(-150, 150, -280); scene.add(moon);
  const glow = new THREE.Mesh(new THREE.SphereGeometry(48, 24, 16), new THREE.MeshBasicMaterial({ color: 0xd84b78, transparent: true, opacity: .18, fog: false, depthWrite: false }));
  glow.position.copy(moon.position); scene.add(glow);

  const n = 700, pos = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const a = Math.random() * 6.283, e = Math.random() * 1.2 + .15, r = 380;
    pos[i * 3] = Math.cos(a) * Math.cos(e) * r; pos[i * 3 + 1] = Math.sin(e) * r; pos[i * 3 + 2] = Math.sin(a) * Math.cos(e) * r;
  }
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 1.6, sizeAttenuation: false, fog: false, transparent: true, opacity: .8 }));
  scene.add(stars);

  scene.add(new THREE.HemisphereLight(0x7f8fd8, 0x2a1d33, 0.9));
  const sun = new THREE.DirectionalLight(0xf2a2b8, 1.4);
  sun.position.set(-60, 90, -80); sun.castShadow = shadows;
  sun.shadow.mapSize.set(2048, 2048);
  const s = sun.shadow.camera; s.left = -90; s.right = 90; s.top = 90; s.bottom = -90; s.near = 10; s.far = 300;
  sun.shadow.bias = -0.0004;
  scene.add(sun);

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(1200, 1200), new THREE.MeshStandardMaterial({ color: 0x24302c, roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; ground.position.y = -0.02; ground.receiveShadow = true; scene.add(ground);

  return { update(cam) { dome.position.copy(cam.position); stars.position.copy(cam.position); } };
}
