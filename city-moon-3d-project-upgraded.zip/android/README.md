# The City That Forgot the Moon — Android project

This folder is a minimal Android Studio project wrapping the self-contained offline game in a WebView.

## Build on Android Studio
1. Open the `android/` folder as a project in Android Studio.
2. Allow Gradle sync to finish (internet may be needed for the first dependency download).
3. Choose **Build > Build APK(s)**.
4. Android Studio normally reports the APK location under `app/build/outputs/apk/debug/`.

## Game asset
`app/src/main/assets/www/index.html` is the bundled offline game, copied from `../dist/city-moon-offline.html`.
It contains the game code and embedded models/textures, so gameplay does not need an internet connection.

## Controls
- Left side: virtual joystick.
- Drag on the right side: rotate the camera.
- Jump and interact buttons: on-screen controls.
- Keyboard testing: WASD/arrows, Space to jump, E/Enter to interact.

## Notes
- The project now includes root Gradle settings and plugin declarations. A Gradle wrapper is not included, so use Android Studio's installed Gradle support or add a wrapper from a compatible Gradle installation.
- The game has not been verified on a physical Android device as part of this ZIP inspection.
- `public/` is the multi-file development version; `dist/city-moon-offline.html` is the self-contained offline build.


## Source of truth and APK build

The editable game is in `../public/` (HTML, ES modules, Three.js vendor files, and CC0 Kenney models). The Android build workflow copies this complete folder to `app/src/main/assets/www/` before compiling, so the APK contains the real game and its local assets rather than a generated placeholder. The WebView uses `WebViewAssetLoader`, so ES modules and model files are served from the app and work offline.

The app uses device-local autosave plus three manual save slots. Use Menu → Export save backup to keep a portable JSON copy; import that file on the same or another installation. Touch users have ACT, RUN, and JUMP controls; ambient pedestrians can share optional clues.
