# The City That Forgot the Moon 🌙

An offline-friendly, third-person 3D exploration mystery for Android. The project uses Three.js, locally bundled character/building models, a third-person controller, a five-chapter branching story, ambient procedural audio, and WebViewAssetLoader so the game can run without a network connection after installation.

## Source of truth

- `public/` — editable game source, local Three.js modules, and local 3D assets.
- `android/` — native Android WebView wrapper and Gradle app configuration.
- `tools/test-source.mjs` — source and asset smoke tests.
- `.github/workflows/build-apk.yml` — validates the source, copies the real game into Android assets, builds the APK, verifies it exists, and uploads it as a GitHub Actions artifact.

The APK workflow deliberately packages `public/`; it does not generate a different placeholder game. All runtime scripts, models, and textures are local files.

## Gameplay upgrades

- **Balanced mobile performance:** touch devices default to battery-saving graphics; high graphics can be enabled in the title screen.
- **Touch interaction:** left-side joystick, right-side camera look, and ACT/RUN/JUMP controls.
- **Story:** five chapters, branching choices, clues, trust and compassion values, and memory-fragment collection.
- **NPCs:** ambient pedestrians patrol short routes and can share optional side-quest clues.
- **Save safety:** validated autosaves, three manual save slots, JSON export/import, and local-device persistence.
- **Audio:** procedural ambience, footsteps, jumps, chimes and bells; ambience pauses when the app is backgrounded.

## Build an APK

1. Open the repository's **Actions** tab.
2. Choose **Build City Moon 3D APK**.
3. Tap **Run workflow** on branch `main` (or push a change under `public/` or `android/`).
4. Wait for the run to finish successfully.
5. Download `city-moon-3d-debug-apk` from the run's **Artifacts** section and extract `app-debug.apk`.

A green workflow run verifies that the APK was built and that the output file is non-empty. It does not replace testing on a real Android phone.

## Local checks

From the project root:

```bash
for file in public/src/*.js tools/test-source.mjs; do node --check "$file"; done
node tools/test-source.mjs
```

The Kenney model assets included under `public/assets/` retain their CC0 license file at `public/assets/LICENSE-Kenney.txt`.
