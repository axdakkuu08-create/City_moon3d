# The City That Forgot the Moon — 3D Android Prototype

This is an offline-first 3D story prototype built with raw WebGL (no external libraries or CDN dependencies) and an Android WebView wrapper.

## What it includes
- 3D low-poly moonlit city with buildings, road, moon, lamps, and glowing memory markers
- Third-person player avatar
- Android touch joystick; keyboard WASD/arrow keys for browser testing
- Story interactions and dialogue choices across five chapter labels
- Trust/clue tracking and journal
- Local save support
- Native Android wrapper project
- GitHub Actions workflow to build a debug APK

## Build APK automatically on GitHub
1. Create a new GitHub repository named `city-moon-3d` (or use your own new repo).
2. Upload the contents of this ZIP to the repository root, preserving folders including `.github`.
3. Open the repository's **Actions** tab and select **Build City Moon 3D APK**.
4. Press **Run workflow** (or push files to `main`).
5. Wait for the run to finish, open the successful run, and download the artifact named `city-moon-3d-debug-apk`.
6. Extract that artifact ZIP to get `app-debug.apk`, then install it on your Android phone. You may need to allow installation from your browser or file manager.

## Important
- This is an early playable prototype, not a polished 3D commercial game. Its 3D visuals are procedural low-poly shapes and its story is a compact prototype.
- This environment does not have the Android SDK/Gradle installed, so it cannot compile and verify the APK locally. The included GitHub Actions workflow is the route to build the APK.
- Debug APKs are for testing. A release APK should be signed before public distribution.
